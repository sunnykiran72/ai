# Analyze Batch Summary

| Case | Target | Final Type | Probe Sel | Final Sel | Final Status | Prompt |
| --- | --- | --- | --- | --- | --- | --- |
| Screenshot-2026-04-09-at-8.08.17-PM__top | top | top | True | False | 200 | This garment is a bra. The upper edge features a V-neckline with a central front openin... |
