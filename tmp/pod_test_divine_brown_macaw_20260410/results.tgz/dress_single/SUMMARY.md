# Analyze Batch Summary

| Case | Target | Final Type | Probe Sel | Final Sel | Final Status | Prompt |
| --- | --- | --- | --- | --- | --- | --- |
| Screenshot-2026-04-09-at-8.07.58-PM__dress | dress | dress | False | False | 200 | This garment is a strapless evening dress with a sweetheart neckline, featuring a fitte... |
